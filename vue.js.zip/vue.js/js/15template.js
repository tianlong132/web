//建模版

 var mycomponent=Vue.extend(

     {template:"<div><a href='#'>我爱Javascript!</div>"}

  ); 
 //注册组件
 Vue.component('my-component',mycomponent);